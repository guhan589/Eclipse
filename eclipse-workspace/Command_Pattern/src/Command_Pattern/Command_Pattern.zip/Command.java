package Command_Pattern;

public interface Command {
	public abstract void execute();
}
